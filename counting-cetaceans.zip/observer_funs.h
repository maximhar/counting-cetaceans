#ifndef OBSERVER_FUNS
#define OBSERVER_FUNS
#include "observer.h"
#include "arraydefs.h"
/*read an array of observers from a file*/
array_observer read_observers(char* path);
#endif